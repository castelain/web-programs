#!/bin/bash
#This is a generator of html5 template
echo "<html>"
echo "  <head>"
echo '      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">'
echo "      <title>unnamed</title>"
echo "  </head>"
echo
echo "  <body>"
echo
echo "  </body>"
echo "</html>"
